// ============================================================
// 会計簿アプリ - Google Apps Script
// 既存シート「フォームの回答１」対応版
// 列構成: A=タイムスタンプ B=分類 C=金額 D=通貨 E=支払い方法 F=種類 G=備考 H=JPY I=PHP
// ============================================================

const SHEET_NAME = 'フォームの回答１';

// JPY/PHP換算レート（必要に応じて変更）
const PHP_TO_JPY = 2.663; // 1PHP ≈ 2.663円（適宜更新）

// ============================================================
// GETルーティング（JSONP対応）
// ============================================================
function doGet(e) {
  const p = e.parameter;
  const cb = p.callback;
  let result;

  try {
    switch (p.action) {
      case 'getTransactions': result = getTransactions();         break;
      case 'addTransaction':  result = addTransaction(p);         break;
      case 'deleteTransaction': result = deleteTransaction(p.id); break;
      case 'getSummary':      result = getSummary();              break;
      case 'getCategories':   result = getCategories();           break;
      case 'getPayments':     result = getPayments();             break;
      default:
        result = { success: false, error: '不明なアクション' };
    }
  } catch (err) {
    result = { success: false, error: err.toString() };
  }

  const json = JSON.stringify(result);
  const out = cb ? `${cb}(${json})` : json;
  return ContentService
    .createTextOutput(out)
    .setMimeType(cb ? ContentService.MimeType.JAVASCRIPT : ContentService.MimeType.JSON);
}

// ============================================================
// 全取引を取得
// ============================================================
function getTransactions() {
  try {
    const sheet = getSheet();
    const data = sheet.getDataRange().getValues();
    if (data.length <= 1) return { success: true, data: [] };

    const rows = data.slice(1)
      .filter(r => r[0]) // タイムスタンプが空の行をスキップ
      .map((row, i) => {
        const ts = row[0];
        // タイムスタンプをISO日付文字列に変換
        const dateObj = ts instanceof Date ? ts : new Date(ts);
        const date = isNaN(dateObj) ? String(ts).substring(0, 10) : dateObj.toISOString().split('T')[0];
        const amount = Number(row[2]) || 0;
        const currency = String(row[3]).trim();
        const jpyAmount = Number(row[7]) || (currency === 'JPY' ? amount : Math.round(amount * PHP_TO_JPY));
        const phpAmount = Number(row[8]) || (currency === 'PHP' ? amount : Math.round(amount / PHP_TO_JPY));

        return {
          id: i + 2, // 行番号（ヘッダー=1なので+2）
          timestamp: String(ts),
          date: date,
          type: String(row[1]).trim(),   // 分類（収入/支出）
          amount: amount,
          currency: currency,            // 通貨（JPY/PHP）
          payment: String(row[4]).trim(), // 支払い方法
          category: String(row[5]).trim(), // 種類
          memo: String(row[6]).trim(),    // 備考
          jpy: jpyAmount,
          php: phpAmount,
        };
      })
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    return { success: true, data: rows };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

// ============================================================
// 取引を追加（既存シートの末尾に追記）
// ============================================================
function addTransaction(p) {
  try {
    const sheet = getSheet();
    const amount = Number(p.amount) || 0;
    const currency = p.currency || 'JPY';
    const jpyAmount = currency === 'JPY' ? amount : Math.round(amount * PHP_TO_JPY);
    const phpAmount = currency === 'PHP' ? amount : Math.round(amount / PHP_TO_JPY);

    // タイムスタンプを「YYYY/MM/DD HH:MM:SS」形式で生成
    const now = new Date();
    const ts = Utilities.formatDate(now, 'Asia/Tokyo', 'yyyy/MM/dd HH:mm:ss');

    sheet.appendRow([
      ts,           // A: タイムスタンプ
      p.type,       // B: 分類
      amount,       // C: 金額
      currency,     // D: 通貨
      p.payment,    // E: 支払い方法
      p.category,   // F: 種類
      p.memo || '', // G: 備考
      jpyAmount,    // H: JPY
      phpAmount,    // I: PHP
    ]);

    // 行の色付け（支出=薄赤、収入=薄緑）
    const newRow = sheet.getLastRow();
    sheet.getRange(newRow, 1, 1, 9)
      .setBackground(p.type === '支出' ? '#fff3f3' : '#f3fff3');

    return { success: true };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

// ============================================================
// 取引を削除（行番号で指定）
// ============================================================
function deleteTransaction(id) {
  try {
    const sheet = getSheet();
    const rowNum = Number(id);
    if (isNaN(rowNum) || rowNum < 2) return { success: false, error: '無効な行番号' };
    sheet.deleteRow(rowNum);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

// ============================================================
// 月次サマリーを取得
// ============================================================
function getSummary() {
  try {
    const result = getTransactions();
    if (!result.success) return result;

    const monthly = {};
    result.data.forEach(t => {
      const ym = t.date.substring(0, 7); // YYYY-MM
      if (!monthly[ym]) monthly[ym] = { income_jpy: 0, expense_jpy: 0, income_php: 0, expense_php: 0 };
      if (t.type === '収入') {
        monthly[ym].income_jpy += t.jpy;
        monthly[ym].income_php += t.php;
      } else {
        monthly[ym].expense_jpy += t.jpy;
        monthly[ym].expense_php += t.php;
      }
    });

    const data = Object.entries(monthly)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([month, v]) => ({
        month,
        income_jpy: v.income_jpy, expense_jpy: v.expense_jpy,
        balance_jpy: v.income_jpy - v.expense_jpy,
        income_php: v.income_php, expense_php: v.expense_php,
        balance_php: v.income_php - v.expense_php,
      }));

    return { success: true, data };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

// ============================================================
// カテゴリ一覧（既存データから抽出）
// ============================================================
function getCategories() {
  try {
    const sheet = getSheet();
    const data = sheet.getDataRange().getValues().slice(1);
    const cats = [...new Set(data.map(r => String(r[5]).trim()).filter(Boolean))].sort();
    return { success: true, data: cats };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

// ============================================================
// 支払い方法一覧（既存データから抽出）
// ============================================================
function getPayments() {
  try {
    const sheet = getSheet();
    const data = sheet.getDataRange().getValues().slice(1);
    const payments = [...new Set(data.map(r => String(r[4]).trim()).filter(Boolean))].sort();
    return { success: true, data: payments };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

// ============================================================
// シート取得ヘルパー
// ============================================================
function getSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) throw new Error(`シート「${SHEET_NAME}」が見つかりません`);
  return sheet;
}
